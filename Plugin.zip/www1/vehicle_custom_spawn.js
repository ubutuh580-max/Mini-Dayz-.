(function () {
  // ============================================================
  // MDZ AutoSpawn Building - 5 Buildings
  // Option 1: simpan koordinat di localStorage agar Continue
  // memakai posisi yang sama.
  // ============================================================

  const PLAYER_TYPE = 't181';
  const CHECK_INTERVAL_MS = 3000;
  const RUNTIME_WAIT_MS = 500;
  const ISLANDS_STORAGE_KEY = 'mdz_autospawn_islands_v1';
  const MIN_DISTANCE_FROM_START = 1000;

  // Jarak awal pencarian dari player.
  const SPAWN_DISTANCE = 1500;
  const ATTEMPT_RADIUS_STEP = 200;
  const MAX_PLACEMENT_ATTEMPTS = 20;

  // Jarak minimum antar bangunan dalam 1 grup.
  const BUILDING_SEPARATION = 1800;

  // Jarak minimum dari obstacle.
  const CLEAR_CHECK_RADIUS = 260;

  // Padding tambahan agar footprint bangunan tidak menyentuh bangunan/objek lain.
  const BUILDING_COLLISION_PADDING = 300;

  const ENTER_MARGIN = 20;

  // ============================================================
  // 5 bangunan:
  // 0 = bangunan awal dari script lama
  // 1 = Bus
  // 2 = Bar
  // 3 = City House 2
  // 4 = Village Yard
  // ============================================================
  const CUSTOM_BUILDINGS = [
    {
      name: 'Original Building',
      extType: 't855',
      intType: 't854',
      extImage: 'images/custom_texture.png',
      intImage: 'images/custom_interior.png'
    },
    {
      name: 'Car Bus',
      extType: 't575',
      intType: 't574',
      extImage: 'images/b_car_bus-sheet0_custom.png',
      intImage: 'images/b_car_bus_int-sheet0_custom.png'
    },
    {
      name: 'Bar',
      extType: 't959',
      intType: 't958',
      extImage: 'images/b_bar-sheet0_custom.png',
      intImage: 'images/b_bar_int-sheet0_custom.png'
    },
    {
      name: 'City House 2',
      extType: 't322',
      intType: 't311',
      extImage: 'images/b_city_house_2-sheet0_custom.png',
      intImage: 'images/b_city_house_2_int-sheet0_custom.png'
    },
    {
      name: 'Village Yard',
      extType: 't339',
      intType: 't304',
      extImage: 'images/b_village_yard-sheet0_custom.png',
      intImage: 'images/b_village_yard_int-sheet0_custom.png'
    }
  ];

  const OBSTACLE_LAYER_KEYWORDS = [
    'tree', 'forest', 'buildings', 'static_cars', 'water'
  ];

  function getRuntime() {
    try {
      if (typeof cr_getC2Runtime !== 'undefined' && typeof cr_getC2Runtime === 'function') {
        const rt = cr_getC2Runtime();
        if (rt) return rt;
      }
    } catch (e) {}
    try {
      if (window.cr_getC2Runtime && typeof window.cr_getC2Runtime === 'function') {
        const rt = window.cr_getC2Runtime();
        if (rt) return rt;
      }
    } catch (e) {}
    // Beberapa build mengekspos runtime langsung sebagai global.
    try {
      const candidates = [window.runtime, window.__runtime, window.gameRuntime, window.c3_runtime];
      for (const rt of candidates) {
        if (rt && rt.types && typeof rt.Yn === 'function') return rt;
      }
    } catch (e) {}
    return null;
  }

  // Expose hanya resolver-nya, supaya script Eruda/debugger lain tidak
  // memanggil getRuntime() yang berada di dalam IIFE dan menyebabkan
  // "ReferenceError: getRuntime is not defined".
  window.__mdzGetRuntime = getRuntime;

  function saveIslandsToStorage() {
    try {
      localStorage.setItem(
        ISLANDS_STORAGE_KEY,
        JSON.stringify(window._mdzBuildingCoords || [])
      );
    } catch (e) {
      console.error('[MDZ AutoSpawn] Gagal simpan koordinat:', e.message);
    }
  }

  function loadIslandsFromStorage() {
    try {
      const raw = localStorage.getItem(ISLANDS_STORAGE_KEY);
      if (!raw) return [];
      const data = JSON.parse(raw);
      return Array.isArray(data) ? data : [];
    } catch (e) {
      console.error('[MDZ AutoSpawn] Gagal baca koordinat tersimpan:', e.message);
      return [];
    }
  }

  window.__mdzResetIslands = function () {
    try {
      localStorage.removeItem(ISLANDS_STORAGE_KEY);
      window._mdzIslandsSpawned = [];
      window._mdzIslandsRejected = [];
      window._mdzBuildingCoords = [];
      window._mdzFiveBuildingsSpawned = false;

      try {
        const rt = getRuntime();
        const player = rt && rt.types[PLAYER_TYPE] && rt.types[PLAYER_TYPE].q[0];
        window._mdzStartPos = player ? { x: player.x, y: player.y } : null;
      } catch (e2) {
        window._mdzStartPos = null;
      }

      console.log('[MDZ AutoSpawn] Data 5 bangunan direset. Posisi baru akan dicari.');
    } catch (e) {
      console.error('[MDZ AutoSpawn] Gagal reset:', e.message);
    }
  };

  function installRestartGameHook() {
    try {
      if (typeof c2_callFunction !== 'function' && typeof window.c2_callFunction !== 'function') {
        return false;
      }

      var original = (typeof c2_callFunction === 'function')
        ? c2_callFunction
        : window.c2_callFunction;

      if (original.__mdzAutoSpawnWrapped) return true;

      var wrapped = function (name) {
        if (name === 'Restart_game') {
          console.log('[MDZ AutoSpawn] Restart_game -> reset 5 bangunan.');
          window.__mdzResetIslands();
        }
        return original.apply(this, arguments);
      };

      wrapped.__mdzAutoSpawnWrapped = true;
      window.c2_callFunction = wrapped;
      try { c2_callFunction = wrapped; } catch (e2) {}

      console.log('[MDZ AutoSpawn] Hook Restart_game terpasang.');
      return true;
    } catch (e) {
      console.error('[MDZ AutoSpawn] installRestartGameHook error:', e.message);
      return false;
    }
  }

  function applyCustomTexture(rt, inst, imageUrl, onDone) {
    if (!imageUrl) {
      if (onDone) onDone();
      return;
    }

    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = function () {
      try {
        const texWrapper = rt.H.fd(img, true, rt.Sa, rt.Df);
        inst.$n = texWrapper;

        const newFrame = Object.create(Object.getPrototypeOf(inst.mc));
        Object.assign(newFrame, inst.mc);

        newFrame.N = img;
        newFrame.O = texWrapper;
        newFrame.Ni = imageUrl;
        newFrame.width = inst.width;
        newFrame.height = inst.height;
        newFrame.Wj = 0;
        newFrame.Xj = 0;
        newFrame.jk = false;
        newFrame.rr = '';

        inst.mc = newFrame;
        rt.redraw = true;
      } catch (e) {
        console.error('[MDZ AutoSpawn] Gagal pasang texture:', imageUrl, e.message);
      }

      if (onDone) onDone();
    };

    img.onerror = function () {
      console.error('[MDZ AutoSpawn] Gagal load gambar:', imageUrl);
      if (onDone) onDone();
    };

    img.src = imageUrl;
  }

  function startDoorToggle(rt, cloneExt, cloneInt) {
    setInterval(function () {
      try {
        const player = rt.types[PLAYER_TYPE] && rt.types[PLAYER_TYPE].q[0];
        if (!player || !cloneExt || !cloneInt) return;

        const halfW = cloneExt.width / 2 + ENTER_MARGIN;
        const halfH = cloneExt.height / 2 + ENTER_MARGIN;

        const isInside =
          player.x > cloneExt.x - halfW && player.x < cloneExt.x + halfW &&
          player.y > cloneExt.y - halfH && player.y < cloneExt.y + halfH;

        if (cloneInt.visible !== isInside) {
          cloneExt.visible = !isInside;
          cloneExt.collisionsEnabled = !isInside;
          cloneInt.visible = isInside;

          if (typeof cloneExt.P === 'function') cloneExt.P();
          if (typeof cloneInt.P === 'function') cloneInt.P();
          if (cloneExt.type) cloneExt.type.Hn = true;
          if (cloneInt.type) cloneInt.type.Hn = true;

          rt.redraw = true;
        }
      } catch (e) {
        console.error('[MDZ AutoSpawn] error toggle:', e.message);
      }
    }, 200);
  }

  const MAP_EDGE_MARGIN = 1200;
  const WATER_LAYER_KEYWORDS = ['water','lake','river','ocean','sea','pond','shore','beach'];
  const BLOCK_LAYER_KEYWORDS = [
    'tree','trees','forest','woods','wood','bush','bushes','shrub','shrubs',
    'vegetation','veget','plant','plants','palm','pine','oak','jungle',
    'rock','rocks','stone','stones','water','lake','river','ocean',
    'sea','pond','shore','beach','static_cars','building','buildings'
  ];

  // Nama type juga diperiksa, karena beberapa pohon tidak berada di layer
  // bernama "tree". Ini mencegah bangunan muncul tepat di belakang pohon.
  const BLOCK_TYPE_KEYWORDS = [
    'tree','trees','forest','woods','wood','bush','bushes','shrub','shrubs',
    'vegetation','veget','plant','plants','palm','pine','oak','jungle',
    'rock','rocks','stone','stones'
  ];
  const IGNORE_LAYER_KEYWORDS = ['ui','hud','menu','text','button','touch','joystick','overlay','debug','canvas'];

  function layerName(inst) {
    try { return inst && inst.C && inst.C.name ? String(inst.C.name).toLowerCase() : ''; }
    catch (e) { return ''; }
  }

  function getMapBounds(rt) {
    // Construct map pada data.js memakai koordinat dunia yang bisa negatif.
    // Jangan pernah clamp x/y ke 0. Batas diambil dari instance dunia yang
    // sudah benar-benar dimuat oleh runtime.
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    let count = 0;

    for (const key in rt.types) {
      const t = rt.types[key];
      if (!t || !t.q) continue;
      for (const inst of t.q) {
        try {
          if (!inst.visible || !Number.isFinite(inst.x) || !Number.isFinite(inst.y)) continue;
          const ln = layerName(inst);
          if (IGNORE_LAYER_KEYWORDS.some(k => ln.indexOf(k) !== -1)) continue;

          const w = Math.abs(Number(inst.width) || 0) / 2;
          const h = Math.abs(Number(inst.height) || 0) / 2;
          minX = Math.min(minX, inst.x - w);
          minY = Math.min(minY, inst.y - h);
          maxX = Math.max(maxX, inst.x + w);
          maxY = Math.max(maxY, inst.y + h);
          count++;
        } catch (e) {}
      }
    }

    if (!Number.isFinite(minX) || count < 10) return null;
    return {
      left: minX + MAP_EDGE_MARGIN,
      top: minY + MAP_EDGE_MARGIN,
      right: maxX - MAP_EDGE_MARGIN,
      bottom: maxY - MAP_EDGE_MARGIN
    };
  }

  function isInsideMap(rt, x, y) {
    const b = getMapBounds(rt);
    if (!b) return true;
    return x >= b.left && x <= b.right && y >= b.top && y <= b.bottom;
  }

  function typeName(type) {
    try { return type && type.name ? String(type.name).toLowerCase() : ''; }
    catch (e) { return ''; }
  }

  function getTypeFootprint(type) {
    let maxW = 0, maxH = 0;
    try {
      if (type && type.q) {
        for (const inst of type.q) {
          if (!inst) continue;
          maxW = Math.max(maxW, Math.abs(Number(inst.width) || 0));
          maxH = Math.max(maxH, Math.abs(Number(inst.height) || 0));
        }
      }
      // Beberapa runtime type tidak punya q instance aktif; fallback ke
      // properti ukuran type bila tersedia.
      maxW = Math.max(maxW, Math.abs(Number(type.width) || 0));
      maxH = Math.max(maxH, Math.abs(Number(type.height) || 0));
    } catch (e) {}
    return {
      w: Math.max(maxW, CLEAR_CHECK_RADIUS * 2),
      h: Math.max(maxH, CLEAR_CHECK_RADIUS * 2)
    };
  }

  function getBuildingFootprint(rt, buildingDef) {
    const e = rt.types[buildingDef.extType];
    const i = rt.types[buildingDef.intType];
    const ef = getTypeFootprint(e);
    const inf = getTypeFootprint(i);
    return {
      w: Math.max(ef.w, inf.w),
      h: Math.max(ef.h, inf.h)
    };
  }

  function rectsOverlap(ax, ay, aw, ah, bx, by, bw, bh, pad) {
    const halfA_W = aw * 0.5 + pad;
    const halfA_H = ah * 0.5 + pad;
    const halfB_W = bw * 0.5;
    const halfB_H = bh * 0.5;
    return Math.abs(ax - bx) < (halfA_W + halfB_W) &&
           Math.abs(ay - by) < (halfA_H + halfB_H);
  }

  function isSpotClear(rt, x, y, reservedPoints, buildingDef) {
    if (!isInsideMap(rt, x, y)) return false;

    const footprint = buildingDef
      ? getBuildingFootprint(rt, buildingDef)
      : { w: CLEAR_CHECK_RADIUS * 2, h: CLEAR_CHECK_RADIUS * 2 };

    // 1) Tolak overlap dengan bangunan yang sudah ada.
    // Jangan hanya mengandalkan nama layer: data.js menunjukkan bangunan
    // ditempatkan sebagai instance world-space dengan type t855/t575/etc.
    const buildingTypeIds = new Set();
    for (const def of CUSTOM_BUILDINGS) {
      buildingTypeIds.add(def.extType);
      buildingTypeIds.add(def.intType);
    }

    for (const key in rt.types) {
      const t = rt.types[key];
      if (!t || !t.q) continue;

      const isKnownBuildingType = buildingTypeIds.has(key) ||
        /(^|_)(b_|building)/i.test(typeName(t));

      for (const inst of t.q) {
        try {
          if (!inst.visible || !Number.isFinite(inst.x) || !Number.isFinite(inst.y)) continue;

          const ln = layerName(inst);
          const tn = typeName(t);
          const blockedLayer = ln && BLOCK_LAYER_KEYWORDS.some(function (kw) {
            return ln.indexOf(kw) !== -1;
          });
          const blockedType = tn && BLOCK_TYPE_KEYWORDS.some(function (kw) {
            return tn.indexOf(kw) !== -1;
          });

          // Bangunan selalu dianggap obstacle walaupun layer/type namanya
          // tidak mengandung kata "building".
          if (!blockedLayer && !blockedType && !isKnownBuildingType) continue;

          const iw = Math.max(
            Math.abs(Number(inst.width) || 0),
            CLEAR_CHECK_RADIUS * 2
          );
          const ih = Math.max(
            Math.abs(Number(inst.height) || 0),
            CLEAR_CHECK_RADIUS * 2
          );

          if (rectsOverlap(
            x, y, footprint.w, footprint.h,
            inst.x, inst.y, iw, ih,
            BUILDING_COLLISION_PADDING
          )) {
            return false;
          }
        } catch (e) {}
      }
    }

    // 2) Tolak overlap dengan bangunan yang baru dibuat pada grup yang sama.
    // Pakai footprint persegi panjang, bukan hanya jarak titik tengah.
    if (reservedPoints) {
      for (const p of reservedPoints) {
        const pw = Number(p.w) || footprint.w;
        const ph = Number(p.h) || footprint.h;
        if (rectsOverlap(
          x, y, footprint.w, footprint.h,
          p.x, p.y, pw, ph,
          BUILDING_COLLISION_PADDING
        )) {
          return false;
        }
      }
    }

    return true;
  }

  function findClearSpot(rt, player, reservedPoints, buildingDef) {
    const b = getMapBounds(rt);
    const candidates = [];

    // Pertahankan pencarian sekitar player, tetapi tanpa mengubah koordinat
    // negatif menjadi 0 seperti versi sebelumnya.
    for (let attempt = 0; attempt < MAX_PLACEMENT_ATTEMPTS * 4; attempt++) {
      const dist = SPAWN_DISTANCE + (attempt % MAX_PLACEMENT_ATTEMPTS) * ATTEMPT_RADIUS_STEP;
      const angle = (attempt * 137.507764) * (Math.PI / 180);
      candidates.push({
        x: player.x + Math.cos(angle) * dist,
        y: player.y + Math.sin(angle) * dist
      });
    }

    // Jika area sekitar player tidak cocok, cari beberapa titik acak di
    // envelope map asli yang dihitung dari instance data.js/runtime.
    if (b && b.right > b.left && b.bottom > b.top) {
      for (let i = 0; i < 80; i++) {
        candidates.push({
          x: b.left + Math.random() * (b.right - b.left),
          y: b.top + Math.random() * (b.bottom - b.top)
        });
      }
    }

    for (let i = 0; i < candidates.length; i++) {
      const p = candidates[i];
      if (isSpotClear(rt, p.x, p.y, reservedPoints, buildingDef)) {
        return { x: p.x, y: p.y, attempts: i + 1 };
      }
    }
    return null;
  }

  function spawnBuildingAt(rt, player, x, y, buildingDef) {
    const extType = rt.types[buildingDef.extType];
    const intType = rt.types[buildingDef.intType];

    if (!extType || !intType) {
      console.error(
        '[MDZ AutoSpawn] Tipe tidak ditemukan untuk ' +
        buildingDef.name +
        ' ext=' + buildingDef.extType +
        ' int=' + buildingDef.intType
      );
      return false;
    }

    const cloneExt = rt.Yn(extType, player.C, x, y);
    const cloneInt = rt.Yn(intType, player.C, x, y);

    if (!cloneExt || !cloneInt) {
      console.error('[MDZ AutoSpawn] Gagal spawn ' + buildingDef.name);
      return false;
    }

    let pending = 2;
    function done() {
      pending--;
      if (pending === 0) startDoorToggle(rt, cloneExt, cloneInt);
    }

    applyCustomTexture(rt, cloneExt, buildingDef.extImage, done);
    applyCustomTexture(rt, cloneInt, buildingDef.intImage, done);

    console.log(
      '[MDZ AutoSpawn] ' + buildingDef.name +
      ' spawn x=' + Math.round(x) +
      ' y=' + Math.round(y)
    );

    return true;
  }

  function isNearAnyKnownPoint(list, x, y) {
    for (const p of list || []) {
      const dx = x - p.x;
      const dy = y - p.y;
      if (Math.sqrt(dx * dx + dy * dy) < 24000) return true;
    }
    return false;
  }

  // ============================================================
  // Spawn 5 bangunan sekaligus.
  // Setiap bangunan mendapat posisi random/berbeda dan disimpan
  // bersama typeIndex agar Continue tahu bangunan mana yang dipakai.
  // ============================================================
  function spawnFiveBuildings(rt, player) {
    if (window._mdzFiveBuildingsSpawned) return false;
    if (CUSTOM_BUILDINGS.length !== 5) return false;

    const newRecords = [];
    const reservedPoints = [];

    for (let i = 0; i < CUSTOM_BUILDINGS.length; i++) {
      const def = CUSTOM_BUILDINGS[i];
      const spot = findClearSpot(rt, player, reservedPoints, def);

      if (!spot) {
        console.warn('[MDZ AutoSpawn] Gagal mencari spot untuk ' + def.name + '.');
        return false;
      }

      const record = {
        typeIndex: i,
        x: spot.x,
        y: spot.y
      };

      const fp = getBuildingFootprint(rt, def);
      reservedPoints.push({ x: spot.x, y: spot.y, w: fp.w, h: fp.h });
      newRecords.push(record);
    }

    // Simpan semua koordinat + jenis bangunan sebelum spawn visual.
    window._mdzBuildingCoords = newRecords.slice();
    saveIslandsToStorage();

    let spawnedCount = 0;

    for (const record of newRecords) {
      const def = CUSTOM_BUILDINGS[record.typeIndex];
      if (spawnBuildingAt(rt, player, record.x, record.y, def)) {
        spawnedCount++;
      }
    }

    if (spawnedCount === CUSTOM_BUILDINGS.length) {
      window._mdzFiveBuildingsSpawned = true;
      console.log('[MDZ AutoSpawn] 5 bangunan berhasil spawn dan koordinat disimpan.');
      return true;
    }

    // Kalau salah satu gagal, jangan menganggap grup selesai.
    console.warn('[MDZ AutoSpawn] Hanya ' + spawnedCount + '/5 bangunan berhasil spawn.');
    return false;
  }

  function checkPlayerLocation() {
    const rt = getRuntime();
    if (!rt || !rt.types || !rt.H || typeof rt.Yn !== 'function') return;

    const player = rt.types[PLAYER_TYPE] && rt.types[PLAYER_TYPE].q[0];
    if (!player) return;

    // Kalau sudah ada 5 bangunan dari Continue, tidak spawn ulang.
    if (window._mdzFiveBuildingsSpawned) return;

    if (window._mdzStartPos) {
      const distFromStart = Math.sqrt(
        Math.pow(player.x - window._mdzStartPos.x, 2) +
        Math.pow(player.y - window._mdzStartPos.y, 2)
      );

      if (distFromStart < MIN_DISTANCE_FROM_START) return;
    }

    if (isNearAnyKnownPoint(window._mdzIslandsRejected, player.x, player.y)) return;

    const ok = spawnFiveBuildings(rt, player);

    if (!ok) {
      window._mdzIslandsRejected.push({ x: player.x, y: player.y });
      return;
    }

    window._mdzIslandsSpawned.push({ x: player.x, y: player.y });
  }

  function normalizeSavedRecord(record) {
    // Kompatibilitas dengan save lama yang hanya punya {x,y}.
    if (!record || typeof record.x !== 'number' || typeof record.y !== 'number') {
      return null;
    }

    let typeIndex = Number.isInteger(record.typeIndex)
      ? record.typeIndex
      : 0;

    if (typeIndex < 0 || typeIndex >= CUSTOM_BUILDINGS.length) {
      typeIndex = 0;
    }

    return {
      typeIndex: typeIndex,
      x: record.x,
      y: record.y
    };
  }

  function restoreSavedBuildings(rt, player, savedCoords) {
    const records = [];

    for (const raw of savedCoords) {
      const record = normalizeSavedRecord(raw);
      if (record) records.push(record);
    }

    if (records.length === 0) return false;

    // Kalau save lama hanya menyimpan 1 bangunan {x,y}, jangan merusak
    // save tersebut: bangunan lama tetap dipulihkan sebagai Original Building.
    for (const record of records) {
      const def = CUSTOM_BUILDINGS[record.typeIndex];
      spawnBuildingAt(rt, player, record.x, record.y, def);
    }

    window._mdzBuildingCoords = records.slice();
    window._mdzFiveBuildingsSpawned = records.length >= 5;

    // Jika data lama belum punya typeIndex / belum lengkap 5 bangunan,
    // data tersebut tetap dipakai apa adanya dan tidak diacak ulang.
    console.log(
      '[MDZ AutoSpawn] Continue: ' + records.length +
      ' bangunan dipulihkan dari koordinat tersimpan.'
    );

    return true;
  }

  function boot() {
    if (window._mdzAutoSpawnRunning) return;

    const waitForRuntime = setInterval(function () {
      const rt = getRuntime();
      if (!rt) return;
      clearInterval(waitForRuntime);

      window._mdzAutoSpawnRunning = true;
      window._mdzIslandsSpawned = [];
      window._mdzIslandsRejected = [];
      window._mdzBuildingCoords = [];
      window._mdzFiveBuildingsSpawned = false;

      try {
        const startPlayer = rt.types[PLAYER_TYPE] && rt.types[PLAYER_TYPE].q[0];
        window._mdzStartPos = startPlayer
          ? { x: startPlayer.x, y: startPlayer.y }
          : null;
      } catch (e) {
        console.error('[MDZ AutoSpawn] Gagal catat titik start:', e.message);
        window._mdzStartPos = null;
      }

      // ========================================================
      // CONTINUE:
      // ambil typeIndex + x + y dari localStorage dan spawn tepat
      // di koordinat lama, tanpa mencari lokasi baru.
      // ========================================================
      const savedCoords = loadIslandsFromStorage();
      const player = rt.types[PLAYER_TYPE] && rt.types[PLAYER_TYPE].q[0];

      if (savedCoords.length > 0 && player) {
        restoreSavedBuildings(rt, player, savedCoords);
      }

      setInterval(checkPlayerLocation, CHECK_INTERVAL_MS);

      if (!installRestartGameHook()) {
        var hookRetry = setInterval(function () {
          if (installRestartGameHook()) clearInterval(hookRetry);
        }, 1000);
      }

      console.log(
        '[MDZ AutoSpawn] Aktif - 5 bangunan: ' +
        CUSTOM_BUILDINGS.map(function (b) { return b.name; }).join(', ')
      );
    }, RUNTIME_WAIT_MS);
  }

  if (document.readyState === 'complete') boot();
  else window.addEventListener('load', boot);
})();
