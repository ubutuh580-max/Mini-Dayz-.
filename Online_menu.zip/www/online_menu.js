/**
 * online_menu.js
 * ------------------------------------------------------------
 * Menu UI untuk fitur "Main Online" (ghost multiplayer) -- SUDAH
 * TERSAMBUNG ke server WebSocket beneran (server.js versi room system).
 *
 * - Buat Maps: bikin room baru dengan ID unik -> join -> trigger New Game
 * - Join Server: pilih dari daftar room aktif (fetch dari GET /rooms),
 *   ATAU isi alamat server manual (join room "default" di server itu)
 * - Tombol "Main Online" ditaruh di atas posisi tombol "New Game"
 * - Posisi pemain lain direpresentasikan sebagai "ghost" -- instance
 *   statis yang posisinya di-update manual tiap terima data dari server,
 *   BUKAN digerakkan lewat behavior bawaan engine (pelajaran dari bug
 *   vehicle-spawner sebelumnya). GHOST_TYPE masih placeholder crate
 *   (t795), ganti kalau sudah ketemu sprite yang lebih cocok.
 *
 * Server default: DEFAULT_SERVER_URL (Railway). Ganti konstanta itu kalau
 * server-nya pindah alamat.
 * ------------------------------------------------------------
 */
(function () {
    window.MDZ = window.MDZ || {};

    const BTN_ID = 'mdz-online-toggle';
    const PANEL_ID = 'mdz-online-panel';
    const STORAGE_KEY_SERVER = 'mdz_online_server_url';
    const STORAGE_KEY_NAME = 'mdz_online_nickname';

    // Server default (Railway) -- dipakai buat "Buat Maps" dan "Daftar
    // Server". Tab "Manual" tetap bisa override ke server lain.
    const DEFAULT_SERVER_URL = 'wss://server-online-production.up.railway.app';
    // Endpoint HTTP buat ambil daftar room tanpa perlu buka WebSocket dulu.
    // Diturunkan otomatis dari DEFAULT_SERVER_URL (wss:// -> https://).
    const DEFAULT_SERVER_HTTP = DEFAULT_SERVER_URL.replace(/^wss:/, 'https:').replace(/^ws:/, 'http:');

    // Posisi tombol "Main Online" - perkiraan di atas tombol "New Game"
    // (New Game ada di baris ke-2 dari stack menu tengah). Geser angka
    // ini kalau posisinya kurang pas di device kamu, sama seperti
    // waktu kita atur posisi tombol "Bahasa" sebelumnya.
    const BTN_POSITION = { left: '39.5%', width: '22%', top: '25%', height: '9%' };

    let isConnected = false;
    let currentMode = null; // 'host' | 'join' | null
    let connectionLog = []; // {text, type} - type: 'info' | 'success' | 'system'

    // ================================================================
    // ====== GHOST / POSITION SYNC (dipindah dari multiplayer-sync.js) =
    // ================================================================
    // Beda dari versi standalone sebelumnya: di sini koneksi WebSocket
    // TIDAK otomatis nyambung pas game kebuka -- baru jalan begitu user
    // pilih "Buat Maps" atau "Join Server" dari menu ini.

    const PLAYER_TYPE = 't181';
    // Type ID buat ghost pemain lain -- masih placeholder (crate, 0
    // behavior, sudah terbukti aman di-spawn lewat rt.Yn()). Ganti kalau
    // sudah ketemu sprite yang lebih cocok buat "orang".
    const GHOST_TYPE = 't795';
    const POS_SEND_INTERVAL_MS = 250;
    const POS_MOVE_THRESHOLD = 4;
    const GHOST_STALE_MS = 8000;

    // === ZOMBIE SYNC (Host-Authoritative, tahap 1: posisi doang, visual) ===
    // Type ID zombie AKTIF (15 behavior -- yang HOST scan & broadcast).
    const HOST_ZOMBIE_TYPES = ['t206', 't221', 't401', 't582', 't583'];
    // Type ID buat representasi ghost zombie di sisi JOINER -- sengaja
    // pakai sprite "zombie mati" (statis, 0 behavior) biar aman di-spawn
    // lewat rt.Yn(), sama pola kayak ghost player pakai crate.
    const GHOST_ZOMBIE_TYPE = 't219';
    const ZOMBIE_BROADCAST_INTERVAL_MS = 500;
    const ZOMBIE_GHOST_STALE_MS = 3000; // lebih pendek dari player -- zombie mati harus cepat ilang

    let zombieBroadcastTimer = null;
    const zombieGhosts = {}; // zombieUid -> { instance, lastUpdate }

    // === CHAT ===
    const CHAT_MAX_MESSAGES = 100; // batasi histori biar nggak numpuk terus
    let chatMessages = []; // {nickname, text, ts, isMe}
    let chatPanelVisible = false;
    let hasUnreadChat = false;

    function sendChatMessage(text) {
        text = (text || '').trim();
        if (!text || !ws || ws.readyState !== WebSocket.OPEN) return;

        // Echo lokal langsung -- nggak perlu nunggu server mantulin balik,
        // biar kerasa responsif buat pengirim sendiri.
        chatMessages.push({ nickname: myNickname || 'Kamu', text: text, ts: Date.now(), isMe: true });
        if (chatMessages.length > CHAT_MAX_MESSAGES) chatMessages.shift();
        renderChatMessagesIfVisible();

        try {
            ws.send(JSON.stringify({ type: 'chat', text: text, nickname: myNickname || 'Player' }));
        } catch (e) { /* diamkan */ }
    }

    function receiveChatMessage(data) {
        chatMessages.push({ nickname: data.nickname || data.playerId, text: data.text, ts: data.ts || Date.now(), isMe: false });
        if (chatMessages.length > CHAT_MAX_MESSAGES) chatMessages.shift();

        if (!chatPanelVisible) hasUnreadChat = true;
        renderChatMessagesIfVisible();
        updateChatBadge();
    }

    function clearChatMessages() {
        chatMessages = [];
        hasUnreadChat = false;
    }

    let ws = null;
    let myPlayerId = null;
    let myNickname = null;
    let lastSentX = null, lastSentY = null;
    const ghosts = {}; // playerId -> { instance, lastUpdate }
    let posLoopTimer = null;

    function mpGetRuntime() {
        if (typeof cr_getC2Runtime !== 'undefined') return cr_getC2Runtime();
        return window.runtSCRIPT || null;
    }

    const _sTag = String.fromCharCode(83); // "S"

    function mpGetInstances(t) {
        if (t.instances) return t.instances;
        if (t._mdz_inst_prop) {
            const v = t[t._mdz_inst_prop];
            if (Array.isArray(v)) return v;
            delete t._mdz_inst_prop;
        }
        for (let k in t) {
            let v = t[k];
            if (Array.isArray(v) && v[0] && typeof v[0].uid === 'number') {
                t._mdz_inst_prop = k;
                return v;
            }
        }
        return [];
    }

    function mpGetPlayerInstance(rt) {
        const pType = rt[_sTag].find(function (t) { return t.name === PLAYER_TYPE; });
        if (!pType) return null;
        const arr = mpGetInstances(pType);
        return arr[0] || null;
    }

    function mpIsInsideMap(rt) {
        return !!mpGetPlayerInstance(rt);
    }

    function updateGhostPosition(playerId, x, y) {
        const rt = mpGetRuntime();
        if (!rt) return;

        let ghost = ghosts[playerId];
        if (!ghost) {
            const player = mpGetPlayerInstance(rt);
            const layer = player ? player.C : null;
            if (!layer) return;

            const ghostType = rt[_sTag].find(function (t) { return t.name === GHOST_TYPE; });
            if (!ghostType) return;

            let inst = null;
            try {
                inst = rt.Yn(ghostType, layer, x, y);
            } catch (e) {
                console.error('[MDZ Online] Gagal spawn ghost:', e);
                return;
            }
            if (!inst) return;

            if (typeof inst.collisionsEnabled === 'boolean') inst.collisionsEnabled = false;

            ghost = { instance: inst, lastUpdate: Date.now() };
            ghosts[playerId] = ghost;
        }

        ghost.instance.x = x;
        ghost.instance.y = y;
        ghost.lastUpdate = Date.now();
        rt.redraw = true;
    }

    function removeGhost(playerId) {
        const ghost = ghosts[playerId];
        if (!ghost) return;
        try {
            ghost.instance.visible = false;
            if (typeof ghost.instance.collisionsEnabled === 'boolean') ghost.instance.collisionsEnabled = false;
            ghost.instance.x = -99999;
            ghost.instance.y = -99999;
        } catch (e) { /* diamkan */ }
        delete ghosts[playerId];
    }

    function removeAllGhosts() {
        Object.keys(ghosts).forEach(removeGhost);
    }

    function cleanupStaleGhosts() {
        const now = Date.now();
        Object.keys(ghosts).forEach(function (playerId) {
            if (now - ghosts[playerId].lastUpdate > GHOST_STALE_MS) removeGhost(playerId);
        });
    }

    // --- HOST SIDE: scan zombie aktif, kirim snapshot ke server ---
    function scanAndBroadcastZombies() {
        if (!ws || ws.readyState !== WebSocket.OPEN) return;
        const rt = mpGetRuntime();
        if (!rt || !mpIsInsideMap(rt)) return;

        const list = [];
        try {
            HOST_ZOMBIE_TYPES.forEach(function (typeName) {
                const t = rt[_sTag].find(function (tt) { return tt.name === typeName; });
                if (!t) return;
                mpGetInstances(t).forEach(function (inst) {
                    if (!inst || !inst.visible) return;
                    list.push({ uid: inst.uid, x: Math.round(inst.x), y: Math.round(inst.y) });
                });
            });
        } catch (e) {
            console.warn('[MDZ Online] Error scan zombie:', e);
            return;
        }

        try {
            ws.send(JSON.stringify({ type: 'zombies', list: list }));
        } catch (e) { /* diamkan */ }
    }

    function startZombieBroadcastLoop() {
        if (zombieBroadcastTimer) return;
        zombieBroadcastTimer = setInterval(scanAndBroadcastZombies, ZOMBIE_BROADCAST_INTERVAL_MS);
    }

    function stopZombieBroadcastLoop() {
        if (zombieBroadcastTimer) { clearInterval(zombieBroadcastTimer); zombieBroadcastTimer = null; }
    }

    // --- JOINER SIDE: render/update ghost zombie dari snapshot host ---
    function updateZombieGhosts(list) {
        const rt = mpGetRuntime();
        if (!rt) return;
        const player = mpGetPlayerInstance(rt);
        const layer = player ? player.C : null;
        if (!layer) return;

        const seenUids = {};

        list.forEach(function (z) {
            seenUids[z.uid] = true;
            let ghost = zombieGhosts[z.uid];

            if (!ghost) {
                const ghostType = rt[_sTag].find(function (t) { return t.name === GHOST_ZOMBIE_TYPE; });
                if (!ghostType) return;

                let inst = null;
                try {
                    inst = rt.Yn(ghostType, layer, z.x, z.y);
                } catch (e) {
                    console.error('[MDZ Online] Gagal spawn ghost zombie:', e);
                    return;
                }
                if (!inst) return;

                if (typeof inst.collisionsEnabled === 'boolean') inst.collisionsEnabled = false;
                ghost = { instance: inst, lastUpdate: Date.now() };
                zombieGhosts[z.uid] = ghost;
            }

            ghost.instance.x = z.x;
            ghost.instance.y = z.y;
            ghost.lastUpdate = Date.now();
        });

        // Zombie yang nggak ada lagi di snapshot terbaru (mati/despawn di
        // sisi host) langsung dihapus, nggak nunggu stale timeout, biar
        // kematiannya kerasa cepat.
        Object.keys(zombieGhosts).forEach(function (uid) {
            if (!seenUids[uid]) removeZombieGhost(uid);
        });

        rt.redraw = true;
    }

    function removeZombieGhost(uid) {
        const ghost = zombieGhosts[uid];
        if (!ghost) return;
        try {
            ghost.instance.visible = false;
            if (typeof ghost.instance.collisionsEnabled === 'boolean') ghost.instance.collisionsEnabled = false;
            ghost.instance.x = -99999;
            ghost.instance.y = -99999;
        } catch (e) { /* diamkan */ }
        delete zombieGhosts[uid];
    }

    function removeAllZombieGhosts() {
        Object.keys(zombieGhosts).forEach(removeZombieGhost);
    }

    function cleanupStaleZombieGhosts() {
        const now = Date.now();
        Object.keys(zombieGhosts).forEach(function (uid) {
            if (now - zombieGhosts[uid].lastUpdate > ZOMBIE_GHOST_STALE_MS) removeZombieGhost(uid);
        });
    }

    function sendMyPosition() {
        if (!ws || ws.readyState !== WebSocket.OPEN || !myPlayerId) return;
        const rt = mpGetRuntime();
        if (!rt) return;
        const player = mpGetPlayerInstance(rt);
        if (!player) return;

        if (lastSentX !== null) {
            const dx = player.x - lastSentX, dy = player.y - lastSentY;
            if (Math.sqrt(dx * dx + dy * dy) < POS_MOVE_THRESHOLD) return;
        }
        lastSentX = player.x;
        lastSentY = player.y;

        try {
            ws.send(JSON.stringify({ type: 'pos', x: player.x, y: player.y }));
        } catch (e) { /* diamkan */ }
    }

    function startPositionSyncLoop() {
        if (posLoopTimer) return;
        posLoopTimer = setInterval(function () {
            try {
                const rt = mpGetRuntime();
                if (!rt || !mpIsInsideMap(rt)) return;
                sendMyPosition();
                cleanupStaleGhosts();
                cleanupStaleZombieGhosts();
            } catch (e) {
                console.warn('[MDZ Online] Error posLoop:', e);
            }
        }, POS_SEND_INTERVAL_MS);
    }

    function stopPositionSyncLoop() {
        if (posLoopTimer) { clearInterval(posLoopTimer); posLoopTimer = null; }
        lastSentX = null; lastSentY = null;
        removeAllGhosts();
        stopZombieBroadcastLoop();
        removeAllZombieGhosts();
    }

    // Konek ke server WS tertentu, JANGAN auto-join room -- pemanggil
    // (hostMaps/joinServer) yang urus join setelah koneksi "welcome" masuk.
    function connectToServer(serverUrl, onWelcome, onError) {
        try {
            ws = new WebSocket(serverUrl);
        } catch (e) {
            if (onError) onError(e.message);
            return;
        }

        ws.onopen = function () {
            logMessage('Socket terbuka, menunggu server...', 'info');
        };

        ws.onmessage = function (evt) {
            let data;
            try { data = JSON.parse(evt.data); } catch (e) { return; }

            if (data.type === 'welcome') {
                myPlayerId = data.playerId;
                if (onWelcome) onWelcome(data.playerId);
            } else if (data.type === 'joined') {
                logMessage('Masuk room: ' + data.roomId, 'success');
                startPositionSyncLoop();
                // Cuma HOST yang scan & broadcast zombie -- joiner cuma
                // nerima lewat handler 'zombies' di bawah, nggak usah scan
                // punya sendiri (dia bukan sumber kebenaran).
                if (currentMode === 'host') startZombieBroadcastLoop();
            } else if (data.type === 'pos') {
                updateGhostPosition(data.playerId, data.x, data.y);
            } else if (data.type === 'zombies') {
                // Kalau kita sendiri yang host, abaikan (harusnya nggak
                // pernah nerima balik punya sendiri karena server exclude
                // pengirim, tapi jaga-jaga aja).
                if (currentMode !== 'host') updateZombieGhosts(data.list);
            } else if (data.type === 'chat') {
                receiveChatMessage(data);
            } else if (data.type === 'leave') {
                removeGhost(data.playerId);
                logMessage('Pemain lain keluar.', 'info');
            }
        };

        ws.onclose = function () {
            if (isConnected) logMessage('Koneksi terputus.', 'info');
            isConnected = false;
            myPlayerId = null;
            stopPositionSyncLoop();
        };

        ws.onerror = function () {
            if (onError) onError('Gagal konek ke server.');
        };
    }

    function disconnectFromServer() {
        stopPositionSyncLoop();
        if (ws) {
            try { ws.close(); } catch (e) { /* diamkan */ }
            ws = null;
        }
        myPlayerId = null;
        isConnected = false;
    }
    // ================================================================
    // ====== AKHIR BAGIAN GHOST / POSITION SYNC =====================
    // ================================================================

    function logMessage(text, type = 'info') {
        connectionLog.push({ text, type });
        if (connectionLog.length > 50) connectionLog.shift(); // batasi biar tidak kepanjangan
        renderLogIfVisible();
    }

    function clearLog() {
        connectionLog = [];
    }

    function renderLogIfVisible() {
        const logBox = document.getElementById('mdz-online-log');
        if (!logBox) return; // panel status belum/tidak lagi terbuka
        logBox.innerHTML = connectionLog.map(entry => {
            const color = entry.type === 'success' ? '#4f8' : entry.type === 'system' ? '#ff0' : '#ccc';
            return `<div style="color:${color};">${entry.text}</div>`;
        }).join('');
        logBox.scrollTop = logBox.scrollHeight;
    }

    // Panggil c2_callFunction('Restart_game', ...) dengan RETRY -- fungsi
    // global ini nggak selalu langsung ada pas game baru kebuka (sama
    // persis kejadian yang udah diantisipasi mdz_autospawn_building.js).
    // Coba tiap 500ms sampai ketemu, maksimal ~10 detik, baru nyerah kalau
    // beneran nggak pernah muncul.
    function callRestartGameWithRetry(p1, p2, onSuccess, onGiveUp) {
        let attempts = 0;
        const MAX_ATTEMPTS = 20; // 20 x 500ms = 10 detik

        function tryOnce() {
            attempts++;
            const fn = window.c2_callFunction || (typeof c2_callFunction !== 'undefined' ? c2_callFunction : null);
            if (typeof fn === 'function') {
                try {
                    const result = fn('Restart_game', [p1, p2]);
                    if (onSuccess) onSuccess(result);
                } catch (e) {
                    if (onGiveUp) onGiveUp('Restart_game error: ' + e.message);
                }
                return;
            }
            if (attempts >= MAX_ATTEMPTS) {
                if (onGiveUp) onGiveUp('c2_callFunction tidak pernah muncul setelah ' + (MAX_ATTEMPTS * 0.5) + ' detik.');
                return;
            }
            setTimeout(tryOnce, 500);
        }
        tryOnce();
    }

    // --- API publik ---
    window.MDZ.online = {
        isConnected: () => isConnected,

        // "Buat Maps" -- host bikin room baru dengan ID unik, lalu (kalau
        // berhasil join) trigger New Game.
        hostMaps: function (nickname) {
            clearLog();
            clearChatMessages();
            currentMode = 'host';
            myNickname = nickname;
            renderStatusScreen();
            logMessage('Connecting...', 'info');

            const roomId = nickname + '-' + Math.floor(Math.random() * 9000 + 1000);

            connectToServer(DEFAULT_SERVER_URL, function () {
                logMessage('Connected!', 'success');
                logMessage('Host init... (room: ' + roomId + ')', 'info');

                ws.send(JSON.stringify({ type: 'joinRoom', roomId: roomId }));
                isConnected = true;
                logMessage('Host Ready: ' + roomId, 'system');

                logMessage('Menunggu game siap...', 'info');
                callRestartGameWithRetry(0, 0, function () {
                    logMessage('Game dimulai.', 'success');
                    renderStatusScreen();
                }, function (errMsg) {
                    logMessage('Gagal mulai game: ' + errMsg, 'info');
                    renderStatusScreen();
                });
                renderStatusScreen();
            }, function (errMsg) {
                logMessage('Error: ' + errMsg, 'info');
                renderStatusScreen();
            });
        },

        // "Join Server" -- konek ke server (default atau custom lewat tab
        // Manual) lalu join room tertentu (atau room "default" kalau dari
        // tab Manual, karena di situ nggak ada input nama room).
        joinServer: function (serverUrl, nickname, roomId) {
            clearLog();
            clearChatMessages();
            currentMode = 'join';
            myNickname = nickname;
            renderStatusScreen();
            logMessage('Connecting...', 'info');

            const targetRoom = roomId || 'default';

            connectToServer(serverUrl, function () {
                logMessage('Connected!', 'success');
                ws.send(JSON.stringify({ type: 'joinRoom', roomId: targetRoom }));
                isConnected = true;
                logMessage('System: Kamu masuk sebagai ' + nickname, 'system');

                logMessage('Menunggu game siap...', 'info');
                callRestartGameWithRetry(0, 0, function () {
                    logMessage('Game dimulai.', 'success');
                    renderStatusScreen();
                }, function (errMsg) {
                    logMessage('Gagal mulai game: ' + errMsg, 'info');
                    renderStatusScreen();
                });
                renderStatusScreen();
            }, function (errMsg) {
                logMessage('Error: ' + errMsg, 'info');
                renderStatusScreen();
            });
        },

        disconnect: function () {
            logMessage('Disconnected.', 'info');
            disconnectFromServer();
            currentMode = null;
            clearChatMessages();
            hideChatPanel();
            renderChoiceScreen();
        },

        // Dipanggil dari "sisi lain" nanti kalau ada pemain baru gabung
        // (placeholder API supaya siap dipakai logika WebSocket asli)
        notifyClientConnected: function (nickname) {
            logMessage('Client connected!', 'success');
            logMessage('System: Friend is now ' + nickname, 'system');
        },

        // --- Alat bantu tes: coba panggil Restart_game dengan parameter berbeda ---
        testRestartGame: function (p1, p2) {
            alert('Menunggu c2_callFunction siap (retry sampai 10 detik)...');
            callRestartGameWithRetry(p1, p2, function (result) {
                console.log('[MDZ Online] Restart_game(' + p1 + ',' + p2 + ') -> return:', result);
                alert('Berhasil dipanggil Restart_game(' + p1 + ', ' + p2 + ') setelah nunggu. Cek apakah game mulai baru / pindah layar.');
            }, function (errMsg) {
                alert('Gagal: ' + errMsg);
            });
        }
    };

    // Ambil daftar room aktif dari server default lewat HTTP (nggak perlu
    // buka WebSocket dulu cuma buat lihat daftar). Async -- pemanggil
    // (renderJoinScreen) yang urus tampilan loading/hasilnya.
    function fetchServerList(onDone) {
        fetch(DEFAULT_SERVER_HTTP + '/rooms')
            .then(function (res) { return res.json(); })
            .then(function (data) {
                const rooms = (data.rooms || []).map(function (r) {
                    return { name: r.roomId, url: DEFAULT_SERVER_URL, roomId: r.roomId, players: r.count + ' pemain' };
                });
                onDone(rooms, null);
            })
            .catch(function (err) {
                onDone([], err.message);
            });
    }

    // --- Deteksi apakah sedang di menu utama (bukan loading/di dalam map) ---
    let _cachedPropNames = null;

    function detectPropNames(runtime) {
        if (_cachedPropNames) return;
        const isMinified = 'S' in runtime;
        _cachedPropNames = { layout: isMinified ? 'wa' : 'running_layout' };
    }

    function getRuntime() {
        const runtime = window.cr_getC2Runtime ? window.cr_getC2Runtime() : null;
        if (runtime && !_cachedPropNames) detectPropNames(runtime);
        return runtime;
    }

    function isOnMenuScreen() {
        try {
            const runtime = getRuntime();
            if (!runtime || !_cachedPropNames) return false; // game belum siap (loading), jangan tampil
            const layoutObj = runtime[_cachedPropNames.layout];
            if (!layoutObj || !layoutObj.name) return false;
            return layoutObj.name === 'Menu';
        } catch (e) {
            return false;
        }
    }

    function updateAllButtonsVisibility() {
        const onMenu = isOnMenuScreen();
        [BTN_ID, 'mdz-restart-test-toggle'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = onMenu ? 'flex' : 'none';
        });
        // Kalau lagi di dalam map, ikut sembunyikan panel-panelnya juga
        // (jaga-jaga kalau lagi terbuka pas pindah layar)
        if (!onMenu) {
            const restartOverlay = document.getElementById('mdz-restart-test-overlay');
            if (restartOverlay) restartOverlay.style.display = 'none';
            closePanel();
        }
    }

    // (Sistem guard kompleks sebelumnya dihapus - kita pakai pola simpel
    // yang sama seperti l_id_lang.js: satu div penuh layar per panel.)

    function injectStyles() {
        if (document.getElementById('mdz-online-style')) return;
        const style = document.createElement('style');
        style.id = 'mdz-online-style';
        style.textContent = `
            #${BTN_ID} {
                position: fixed;
                left: ${BTN_POSITION.left}; top: ${BTN_POSITION.top};
                width: ${BTN_POSITION.width}; height: ${BTN_POSITION.height};
                z-index: 99997; display: flex; align-items: center; justify-content: center;
                cursor: pointer; box-sizing: border-box;
                background: url('images/menu_btn_wood-sheet0.png') no-repeat -1px -1px;
                color: #ffffff; font-family: "Times New Roman", serif; font-size: 15px;
                text-shadow: 1px 1px 1px rgba(0,0,0,0.7); letter-spacing: 1px;
            }
            #${BTN_ID}:hover { background-position: -1px -165px; }
            #${BTN_ID}:active { transform: scale(0.97); }

            #${PANEL_ID} {
                position: fixed; inset: 0; z-index: 9999999; display: none;
                align-items: center; justify-content: center; background: rgba(0,0,0,0.6);
                font-family: Georgia, "Times New Roman", serif;
            }
            #${PANEL_ID} .mdz-online-box {
                background: #241a12; border: 2px solid #6b4324; border-radius: 6px;
                padding: 20px 24px; width: 300px; max-width: 90%; color: #f5ecd8;
                box-shadow: 0 6px 20px rgba(0,0,0,0.6); max-height: 80vh; overflow-y: auto;
                box-sizing: border-box;
            }
            #${PANEL_ID} .mdz-online-title {
                font-size: 18px; font-weight: bold; margin-bottom: 14px; text-align: center; color: #0f8;
            }
            #${PANEL_ID} .mdz-online-subtitle {
                font-size: 12px; text-align: center; color: #aaa; margin-bottom: 16px;
            }
            #${PANEL_ID} label {
                display: block; font-size: 12px; margin-bottom: 4px; color: #ccc;
            }
            #${PANEL_ID} input {
                width: 100%; padding: 8px; margin-bottom: 12px; border-radius: 4px;
                border: 1px solid #555; background: #1a1310; color: #fff; box-sizing: border-box;
                font-family: sans-serif; font-size: 13px;
            }
            #${PANEL_ID} .mdz-online-status {
                text-align: center; font-size: 13px; margin-bottom: 14px; padding: 8px;
                border-radius: 4px; background: rgba(255,255,255,0.05);
            }
            #${PANEL_ID} .mdz-online-status.connected { color: #4f8; }
            #${PANEL_ID} .mdz-online-log {
                background: #0d0d0d; border: 1px solid #333; border-radius: 4px;
                padding: 8px; margin-bottom: 12px; max-height: 140px; overflow-y: auto;
                font-family: monospace; font-size: 11px; line-height: 1.6; text-align: left;
            }
            #${PANEL_ID} .mdz-online-btn {
                width: 100%; height: 39px; display: flex; align-items: center; justify-content: center;
                cursor: pointer; margin-bottom: 8px; box-sizing: border-box;
                background: url('images/menu_btn_wood-sheet0.png') no-repeat -1px -1px;
                color: #fff; font-size: 15px; text-shadow: 1px 1px 1px rgba(0,0,0,0.7);
                font-family: "Times New Roman", serif; letter-spacing: 1px;
            }
            #${PANEL_ID} .mdz-online-btn:hover { background-position: -1px -165px; }
            #${PANEL_ID} .mdz-online-btn:active { transform: scale(0.97); }
            #${PANEL_ID} .mdz-online-back,
            #${PANEL_ID} .mdz-online-close {
                text-align: center; margin-top: 6px; font-size: 12px; color: #999; cursor: pointer;
            }
            #${PANEL_ID} .mdz-tab-row { display: flex; gap: 6px; margin-bottom: 14px; }
            #${PANEL_ID} .mdz-tab {
                flex: 1; text-align: center; padding: 8px; font-size: 12px; cursor: pointer;
                background: rgba(255,255,255,0.06); border-radius: 4px; color: #ccc;
            }
            #${PANEL_ID} .mdz-tab.active { background: rgba(0,255,150,0.15); color: #0f8; font-weight: bold; }
            #${PANEL_ID} .mdz-server-row {
                display: flex; justify-content: space-between; align-items: center;
                padding: 8px; margin-bottom: 6px; background: rgba(255,255,255,0.05);
                border-radius: 4px; font-size: 12px; cursor: pointer;
            }
            #${PANEL_ID} .mdz-server-row:hover { background: rgba(255,255,255,0.1); }
            #${PANEL_ID} .mdz-server-empty { text-align: center; color: #888; font-size: 12px; padding: 12px; }
        `;
        document.head.appendChild(style);
    }

    function getPanelBox() {
        return document.querySelector(`#${PANEL_ID} .mdz-online-box`);
    }

    // --- Layar 1: Pilih Buat Maps / Join Server ---
    function renderChoiceScreen() {
        const box = getPanelBox();
        if (!box) return;
        box.innerHTML = `
            <div class="mdz-online-title">Main Online</div>
            <div class="mdz-online-subtitle">Pilih mode yang mau kamu mainkan</div>
            <div class="mdz-online-btn" id="mdz-online-btn-host">🗺️ Buat Maps</div>
            <div class="mdz-online-btn" id="mdz-online-btn-join">🔗 Join Server</div>
            <div class="mdz-online-close" id="mdz-online-close-btn">Tutup</div>
        `;
        document.getElementById('mdz-online-btn-host').addEventListener('click', renderHostScreen);
        document.getElementById('mdz-online-btn-join').addEventListener('click', () => renderJoinScreen('list'));
        document.getElementById('mdz-online-close-btn').addEventListener('click', closePanel);
    }

    // --- Layar 2a: Buat Maps (jadi host) ---
    function renderHostScreen() {
        const box = getPanelBox();
        if (!box) return;
        const savedName = localStorage.getItem(STORAGE_KEY_NAME) || '';
        box.innerHTML = `
            <div class="mdz-online-title">Buat Maps</div>
            <div class="mdz-online-subtitle">Kamu akan jadi host - pemain lain bisa join ke kamu. Permainan baru akan dimulai.</div>
            <label>Nama Panggilan</label>
            <input type="text" id="mdz-online-name-input" placeholder="Nama kamu" value="${savedName}">
            <div class="mdz-online-btn" id="mdz-online-start-host-btn">Mulai Host</div>
            <div class="mdz-online-back" id="mdz-online-back-btn">‹ Kembali</div>
        `;
        document.getElementById('mdz-online-start-host-btn').addEventListener('click', () => {
            const nickname = document.getElementById('mdz-online-name-input').value.trim();
            if (!nickname) { alert('Isi nama panggilan dulu.'); return; }
            localStorage.setItem(STORAGE_KEY_NAME, nickname);
            window.MDZ.online.hostMaps(nickname);
        });
        document.getElementById('mdz-online-back-btn').addEventListener('click', renderChoiceScreen);
    }

    // --- Layar 2b: Join Server (tab: daftar server / manual) ---
    function renderJoinScreen(tab) {
        const box = getPanelBox();
        if (!box) return;
        const savedServer = localStorage.getItem(STORAGE_KEY_SERVER) || '';
        const savedName = localStorage.getItem(STORAGE_KEY_NAME) || '';

        box.innerHTML = `
            <div class="mdz-online-title">Join Server</div>
            <div class="mdz-tab-row">
                <div class="mdz-tab ${tab === 'list' ? 'active' : ''}" id="mdz-tab-list">Daftar Server</div>
                <div class="mdz-tab ${tab === 'manual' ? 'active' : ''}" id="mdz-tab-manual">Manual</div>
            </div>
            <div id="mdz-join-content"></div>
            <div class="mdz-online-back" id="mdz-online-back-btn">‹ Kembali</div>
        `;

        const content = document.getElementById('mdz-join-content');

        if (tab === 'list') {
            content.innerHTML = `<div class="mdz-server-empty">Memuat daftar server...</div>`;
            fetchServerList(function (servers, errMsg) {
                // Panel bisa aja udah ditutup/pindah layar pas fetch selesai
                const stillOnListTab = document.getElementById('mdz-join-content');
                if (!stillOnListTab) return;

                if (errMsg) {
                    stillOnListTab.innerHTML = `<div class="mdz-server-empty">Gagal ambil daftar server (${errMsg}). Coba tab "Manual".</div>`;
                    return;
                }
                if (servers.length === 0) {
                    stillOnListTab.innerHTML = `<div class="mdz-server-empty">Belum ada room aktif. Buat room baru lewat "Buat Maps", atau coba tab "Manual".</div>`;
                    return;
                }
                stillOnListTab.innerHTML = servers.map((s, i) => `
                    <div class="mdz-server-row" data-idx="${i}">
                        <span>${s.name}</span><span>${s.players || ''}</span>
                    </div>
                `).join('');
                stillOnListTab.querySelectorAll('.mdz-server-row').forEach(row => {
                    row.addEventListener('click', () => {
                        const s = servers[parseInt(row.dataset.idx, 10)];
                        const nickname = savedName || prompt('Nama panggilan kamu:');
                        if (!nickname) return;
                        localStorage.setItem(STORAGE_KEY_NAME, nickname);
                        localStorage.setItem(STORAGE_KEY_SERVER, s.url);
                        window.MDZ.online.joinServer(s.url, nickname, s.roomId);
                    });
                });
            });
        } else {
            content.innerHTML = `
                <label>Alamat Server</label>
                <input type="text" id="mdz-online-server-input" placeholder="ws://alamat-server:port" value="${savedServer}">
                <label>Nama Panggilan</label>
                <input type="text" id="mdz-online-name-input" placeholder="Nama kamu" value="${savedName}">
                <div class="mdz-online-btn" id="mdz-online-join-btn">Gabung</div>
            `;
            document.getElementById('mdz-online-join-btn').addEventListener('click', () => {
                const serverUrl = document.getElementById('mdz-online-server-input').value.trim();
                const nickname = document.getElementById('mdz-online-name-input').value.trim();
                if (!serverUrl) { alert('Isi alamat server dulu.'); return; }
                if (!nickname) { alert('Isi nama panggilan dulu.'); return; }
                localStorage.setItem(STORAGE_KEY_SERVER, serverUrl);
                localStorage.setItem(STORAGE_KEY_NAME, nickname);
                window.MDZ.online.joinServer(serverUrl, nickname, 'default');
            });
        }

        document.getElementById('mdz-tab-list').addEventListener('click', () => renderJoinScreen('list'));
        document.getElementById('mdz-tab-manual').addEventListener('click', () => renderJoinScreen('manual'));
        document.getElementById('mdz-online-back-btn').addEventListener('click', renderChoiceScreen);
    }

    // --- Layar 3: Status setelah terhubung (host atau join) ---
    function renderStatusScreen() {
        const box = getPanelBox();
        if (!box) return;
        const modeLabel = currentMode === 'host' ? 'Sebagai Host (Buat Maps)' : 'Bergabung ke Server';
        const statusText = isConnected ? ('🟢 Terhubung - ' + modeLabel) : ('🟡 Menghubungkan - ' + modeLabel);
        const statusClass = isConnected ? 'connected' : '';

        box.innerHTML = `
            <div class="mdz-online-title">Main Online</div>
            <div class="mdz-online-status ${statusClass}">${statusText}</div>
            <div id="mdz-online-log" class="mdz-online-log"></div>
            <div class="mdz-online-btn" id="mdz-online-disconnect-btn" style="${isConnected ? '' : 'display:none;'}">Putuskan</div>
            <div class="mdz-online-close" id="mdz-online-close-btn">Tutup</div>
        `;
        renderLogIfVisible();

        const disconnectBtn = document.getElementById('mdz-online-disconnect-btn');
        if (disconnectBtn) {
            disconnectBtn.addEventListener('click', () => {
                window.MDZ.online.disconnect();
            });
        }
        document.getElementById('mdz-online-close-btn').addEventListener('click', closePanel);
    }

    function closePanel() {
        const panel = document.getElementById(PANEL_ID);
        if (panel) panel.style.display = 'none';
    }

    function createPanel() {
        if (document.getElementById(PANEL_ID)) return;

        const panel = document.createElement('div');
        panel.id = PANEL_ID;
        panel.innerHTML = `<div class="mdz-online-box"></div>`;
        document.body.appendChild(panel);

        panel.addEventListener('click', (e) => {
            if (e.target === panel) closePanel();
        });
    }

    function openPanel() {
        createPanel();
        const panel = document.getElementById(PANEL_ID);
        panel.style.display = 'flex';
        if (isConnected) renderStatusScreen();
        else renderChoiceScreen();
    }

    // === CHAT UI ===
    function createChatButton() {
        if (document.getElementById('mdz-chat-toggle')) return;

        const btn = document.createElement('div');
        btn.id = 'mdz-chat-toggle';
        btn.innerHTML = '💬<span id="mdz-chat-badge"></span>';
        btn.style.cssText = 'position:fixed; bottom:20px; right:20px; z-index:999999; ' +
            'width:34px; height:34px; border-radius:50%; background:rgba(0,120,255,0.85); ' +
            'color:#fff; display:none; align-items:center; justify-content:center; ' +
            'font-family:sans-serif; font-size:16px; cursor:pointer;';
        document.body.appendChild(btn);

        const overlay = document.createElement('div');
        overlay.id = 'mdz-chat-overlay';
        overlay.style.cssText = 'position:fixed; inset:0; z-index:9999999; display:none; ' +
            'align-items:flex-end; justify-content:center; background:rgba(0,0,0,0.4); ' +
            'font-family:sans-serif;';
        overlay.innerHTML = `
            <div style="background:#111; border:2px solid #08f; border-radius:8px 8px 0 0; padding:10px; width:320px; max-width:95%; height:60vh; max-height:420px; color:#fff; font-size:12px; display:flex; flex-direction:column;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                    <span style="font-weight:bold; color:#08f;">💬 Chat</span>
                    <span id="mdz-chat-close" style="color:#999; cursor:pointer; padding:4px;">✕</span>
                </div>
                <div id="mdz-chat-messages" style="flex:1; overflow-y:auto; background:#000; border-radius:4px; padding:8px; margin-bottom:8px; display:flex; flex-direction:column; gap:4px;"></div>
                <div style="display:flex; gap:6px;">
                    <input type="text" id="mdz-chat-input" placeholder="Ketik pesan..." maxlength="200" style="flex:1; padding:8px; border-radius:4px; border:1px solid #555; background:#222; color:#fff; box-sizing:border-box;">
                    <button id="mdz-chat-send" style="padding:8px 14px; border-radius:4px; border:none; background:#08f; color:#fff;">Kirim</button>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);

        btn.addEventListener('click', function () {
            if (chatPanelVisible) hideChatPanel(); else showChatPanel();
        });
        document.getElementById('mdz-chat-close').addEventListener('click', hideChatPanel);
        overlay.addEventListener('click', function (e) { if (e.target === overlay) hideChatPanel(); });

        function doSend() {
            const input = document.getElementById('mdz-chat-input');
            if (!input) return;
            sendChatMessage(input.value);
            input.value = '';
        }
        document.getElementById('mdz-chat-send').addEventListener('click', doSend);
        document.getElementById('mdz-chat-input').addEventListener('keydown', function (e) {
            if (e.key === 'Enter') doSend();
        });
    }

    function showChatPanel() {
        chatPanelVisible = true;
        hasUnreadChat = false;
        const overlay = document.getElementById('mdz-chat-overlay');
        if (overlay) overlay.style.display = 'flex';
        renderChatMessagesIfVisible();
        updateChatBadge();
    }

    function hideChatPanel() {
        chatPanelVisible = false;
        const overlay = document.getElementById('mdz-chat-overlay');
        if (overlay) overlay.style.display = 'none';
    }

    function renderChatMessagesIfVisible() {
        if (!chatPanelVisible) return;
        const box = document.getElementById('mdz-chat-messages');
        if (!box) return;
        box.innerHTML = chatMessages.map(function (m) {
            const color = m.isMe ? '#0f8' : '#08f';
            const safeName = escapeHtml(m.nickname);
            const safeText = escapeHtml(m.text);
            return `<div><span style="color:${color}; font-weight:bold;">${safeName}:</span> <span style="color:#eee;">${safeText}</span></div>`;
        }).join('');
        box.scrollTop = box.scrollHeight;
    }

    function updateChatBadge() {
        const badge = document.getElementById('mdz-chat-badge');
        if (!badge) return;
        badge.style.cssText = hasUnreadChat
            ? 'position:absolute; top:-2px; right:-2px; width:10px; height:10px; border-radius:50%; background:#f00; border:1px solid #fff;'
            : 'display:none;';
    }

    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    function updateChatButtonVisibility() {
        const btn = document.getElementById('mdz-chat-toggle');
        if (btn) btn.style.display = isConnected ? 'flex' : 'none';
        if (!isConnected) hideChatPanel();
    }

    function createButton() {
        injectStyles();
        if (document.getElementById(BTN_ID)) return;

        const btn = document.createElement('div');
        btn.id = BTN_ID;
        btn.textContent = 'Main Online';
        document.body.appendChild(btn);

        btn.addEventListener('click', openPanel);
    }

    function createRestartTestButton() {
        if (document.getElementById('mdz-restart-test-toggle')) return;

        const toggle = document.createElement('div');
        toggle.id = 'mdz-restart-test-toggle';
        toggle.textContent = '🎮';
        toggle.style.cssText = 'position:fixed; bottom:20px; right:186px; z-index:999999; ' +
            'width:34px; height:34px; border-radius:50%; background:rgba(255,80,0,0.85); ' +
            'color:#fff; display:flex; align-items:center; justify-content:center; ' +
            'font-family:sans-serif; font-size:16px; cursor:pointer;';
        document.body.appendChild(toggle);

        // Satu div penuh layar (sama persis pola modal di l_id_lang.js) -
        // background gelap + kotak konten di tengah, tidak ada elemen
        // backdrop terpisah lagi.
        const overlay = document.createElement('div');
        overlay.id = 'mdz-restart-test-overlay';
        overlay.style.cssText = 'position:fixed; inset:0; z-index:9999999; display:none; ' +
            'align-items:center; justify-content:center; background:rgba(0,0,0,0.6); ' +
            'font-family:sans-serif;';
        overlay.innerHTML = `
            <div style="background:#111; border:2px solid #f80; border-radius:8px; padding:16px; width:240px; max-width:90%; color:#fff; font-size:11px;">
                <div style="font-weight:bold; margin-bottom:6px; color:#f80;">Tes Restart_game(p1, p2)</div>
                <input type="text" id="mdz-restart-p1" placeholder="Param 1 (misal: 0)" style="width:100%; padding:6px; margin-bottom:6px; border-radius:4px; border:1px solid #555; background:#222; color:#fff; box-sizing:border-box;">
                <input type="text" id="mdz-restart-p2" placeholder="Param 2 (misal: 0)" style="width:100%; padding:6px; margin-bottom:6px; border-radius:4px; border:1px solid #555; background:#222; color:#fff; box-sizing:border-box;">
                <div style="display:flex; gap:6px; flex-wrap:wrap; margin-bottom:6px;">
                    <button data-p1="0" data-p2="0" class="mdz-quick-test" style="flex:1; padding:6px; font-size:10px;">0,0</button>
                    <button data-p1="0" data-p2="1" class="mdz-quick-test" style="flex:1; padding:6px; font-size:10px;">0,1</button>
                    <button data-p1="1" data-p2="0" class="mdz-quick-test" style="flex:1; padding:6px; font-size:10px;">1,0</button>
                    <button data-p1="204" data-p2="0" class="mdz-quick-test" style="flex:1; padding:6px; font-size:10px;">204,0</button>
                    <button data-p1="205" data-p2="0" class="mdz-quick-test" style="flex:1; padding:6px; font-size:10px;">205,0</button>
                </div>
                <button id="mdz-restart-test-btn" style="width:100%; padding:8px; border-radius:4px; border:none; background:#f80; color:#fff; margin-bottom:6px;">Tes dengan Input Manual</button>
                <div id="mdz-restart-test-close" style="text-align:center; color:#999; cursor:pointer; font-size:11px;">Tutup</div>
            </div>
        `;
        document.body.appendChild(overlay);

        function openTestPanel() { overlay.style.display = 'flex'; }
        function closeTestPanel() { overlay.style.display = 'none'; }

        toggle.addEventListener('click', () => {
            if (overlay.style.display === 'flex') closeTestPanel();
            else openTestPanel();
        });
        // Klik area gelap di luar kotak juga menutupnya (sama seperti l_id_lang.js)
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) closeTestPanel();
        });

        overlay.querySelectorAll('.mdz-quick-test').forEach(b => {
            b.addEventListener('click', () => {
                window.MDZ.online.testRestartGame(parseFloat(b.dataset.p1), parseFloat(b.dataset.p2));
            });
        });

        document.getElementById('mdz-restart-test-btn').addEventListener('click', () => {
            const p1 = parseFloat(document.getElementById('mdz-restart-p1').value.trim());
            const p2 = parseFloat(document.getElementById('mdz-restart-p2').value.trim());
            if (isNaN(p1) || isNaN(p2)) { alert('Isi kedua parameter dengan angka.'); return; }
            window.MDZ.online.testRestartGame(p1, p2);
        });
        document.getElementById('mdz-restart-test-close').addEventListener('click', closeTestPanel);
    }

    if (document.readyState === "complete") { createButton(); createRestartTestButton(); createChatButton(); }
    else window.addEventListener("load", () => { createButton(); createRestartTestButton(); createChatButton(); });

    setInterval(function () { updateAllButtonsVisibility(); updateChatButtonVisibility(); }, 500);
})();
